package com.example.shop.testDate.dto;

import java.sql.Date;



public class BoardReviewDTO {
	private int num, readcount, ref, re_step, re_level;
	private String subject, content, ip;
	private Date reg_date;
	

}
