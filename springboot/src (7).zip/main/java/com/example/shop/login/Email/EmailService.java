package com.example.shop.login.Email;

public interface EmailService {
	 public void sendEmail(String to, String subject, String body);
}
