package com.example.shop.wishList.dto;

import lombok.Data;

@Data
public class Wish_Select_UserDTO {

	private String t_id;
}
