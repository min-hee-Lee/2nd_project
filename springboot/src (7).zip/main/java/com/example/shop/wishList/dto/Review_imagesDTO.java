package com.example.shop.wishList.dto;

import lombok.Data;

@Data
public class Review_imagesDTO {

	private String filename;
	private String filepath;
	
}
