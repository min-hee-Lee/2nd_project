package com.example.shop.payments.dto;

import lombok.Data;

@Data
public class Booking_Time_CheckDTO {

	private int main_code;
	private String use_date;
	
	private String start_time;
	private String end_time;
	
	
	
}
