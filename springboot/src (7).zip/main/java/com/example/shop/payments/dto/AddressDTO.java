package com.example.shop.payments.dto;

import java.util.List;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
public class AddressDTO {

	private String main_address;
	
}
