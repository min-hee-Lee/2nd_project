package com.example.shop.webCrawling.dto;

import java.io.IOException;


public enum Path {
    HOST_THUMB_20210706,
    PROD_IMG_20210706
    // Enum 값들 정의
}
