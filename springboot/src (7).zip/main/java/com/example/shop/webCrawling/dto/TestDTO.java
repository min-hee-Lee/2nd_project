package com.example.shop.webCrawling.dto;

import lombok.Data;

@Data
public class TestDTO {
	
	private String name;	
}
